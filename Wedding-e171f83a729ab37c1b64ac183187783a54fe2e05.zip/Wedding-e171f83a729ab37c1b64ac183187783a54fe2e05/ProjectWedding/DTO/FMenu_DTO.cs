﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class FMenu_DTO
    {
        private string maMenu { get; set; }
        private int donGia { get; set; }
        private int maHD { get; set; }
        private string ghiChu { get; set; }
    }
}
