﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class FMonAn_DTO
    {
        public int maMonAn { get; set; }
        public string tenMonAn { get; set; }
        public int donGia { get; set; }
    }

}
