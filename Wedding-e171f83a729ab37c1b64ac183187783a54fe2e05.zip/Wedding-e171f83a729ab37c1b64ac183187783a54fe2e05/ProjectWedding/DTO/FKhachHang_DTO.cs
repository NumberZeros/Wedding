﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class FKhachHang_DTO
    {
       // thay doi
       public int maKH { get; set; }
       public string tenCR { get; set; }
       public string tenCD { get; set; }
       public int soDT { get; set; }
       public int maHD { get; set; }
    }
}
