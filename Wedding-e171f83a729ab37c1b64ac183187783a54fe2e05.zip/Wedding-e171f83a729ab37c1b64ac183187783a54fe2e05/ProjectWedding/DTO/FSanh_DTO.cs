﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class FSanh_DTO
    {
        public int maSanh { get; set; }
        public string tenSanh { get; set; }
        public string loaiSanh { get; set; }
        public int soluongMax { get; set; }
        public int donGiaMin { get; set; }
        public string ghiChu { get; set; }
        public string maCTDT { get; set; }

    }
}
