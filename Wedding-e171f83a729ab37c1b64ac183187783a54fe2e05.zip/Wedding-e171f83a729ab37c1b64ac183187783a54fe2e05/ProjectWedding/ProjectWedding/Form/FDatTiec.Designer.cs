﻿namespace ProjectWedding
{
    partial class FDatTiec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btdtReturn = new System.Windows.Forms.Button();
            this.tbTenCR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTenCD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NgayDT = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.tbTienCoc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbSlBan = new System.Windows.Forms.TextBox();
            this.cbSanh = new System.Windows.Forms.ComboBox();
            this.btXuathoadon = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btDatTiec = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cbCa = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btdtReturn
            // 
            this.btdtReturn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btdtReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btdtReturn.Image = global::ProjectWedding.Properties.Resources.back_arrow;
            this.btdtReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btdtReturn.Location = new System.Drawing.Point(21, 12);
            this.btdtReturn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btdtReturn.Name = "btdtReturn";
            this.btdtReturn.Size = new System.Drawing.Size(100, 31);
            this.btdtReturn.TabIndex = 0;
            this.btdtReturn.Text = "Return";
            this.btdtReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btdtReturn.UseVisualStyleBackColor = false;
            this.btdtReturn.Click += new System.EventHandler(this.btdtReturn_Click);
            // 
            // tbTenCR
            // 
            this.tbTenCR.Location = new System.Drawing.Point(259, 97);
            this.tbTenCR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbTenCR.Name = "tbTenCR";
            this.tbTenCR.Size = new System.Drawing.Size(233, 22);
            this.tbTenCR.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(167, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tên chú rể";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(165, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tên cô dâu";
            // 
            // tbTenCD
            // 
            this.tbTenCD.Location = new System.Drawing.Point(259, 140);
            this.tbTenCD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbTenCD.Name = "tbTenCD";
            this.tbTenCD.Size = new System.Drawing.Size(233, 22);
            this.tbTenCD.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(167, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Điện thoại";
            // 
            // tbDT
            // 
            this.tbDT.Location = new System.Drawing.Point(259, 183);
            this.tbDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbDT.Name = "tbDT";
            this.tbDT.Size = new System.Drawing.Size(233, 22);
            this.tbDT.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(367, 231);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ca";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(172, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Loại Sảnh";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(131, 366);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Ngày Đặt Tiệc";
            // 
            // NgayDT
            // 
            this.NgayDT.Location = new System.Drawing.Point(240, 361);
            this.NgayDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NgayDT.Name = "NgayDT";
            this.NgayDT.Size = new System.Drawing.Size(252, 22);
            this.NgayDT.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(167, 321);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Tiền cọc";
            // 
            // tbTienCoc
            // 
            this.tbTienCoc.Location = new System.Drawing.Point(259, 319);
            this.tbTienCoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbTienCoc.Name = "tbTienCoc";
            this.tbTienCoc.Size = new System.Drawing.Size(233, 22);
            this.tbTienCoc.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(167, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Số lượng bàn";
            // 
            // tbSlBan
            // 
            this.tbSlBan.Location = new System.Drawing.Point(275, 272);
            this.tbSlBan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSlBan.Name = "tbSlBan";
            this.tbSlBan.Size = new System.Drawing.Size(217, 22);
            this.tbSlBan.TabIndex = 16;
            // 
            // cbSanh
            // 
            this.cbSanh.FormattingEnabled = true;
            this.cbSanh.Location = new System.Drawing.Point(257, 231);
            this.cbSanh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbSanh.Name = "cbSanh";
            this.cbSanh.Size = new System.Drawing.Size(104, 24);
            this.cbSanh.TabIndex = 18;
            // 
            // btXuathoadon
            // 
            this.btXuathoadon.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btXuathoadon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXuathoadon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btXuathoadon.Location = new System.Drawing.Point(609, 255);
            this.btXuathoadon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btXuathoadon.Name = "btXuathoadon";
            this.btXuathoadon.Size = new System.Drawing.Size(141, 57);
            this.btXuathoadon.TabIndex = 19;
            this.btXuathoadon.Text = "Xuất hóa đơn";
            this.btXuathoadon.UseVisualStyleBackColor = false;
            this.btXuathoadon.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnCheck.Location = new System.Drawing.Point(609, 28);
            this.btnCheck.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(141, 57);
            this.btnCheck.TabIndex = 20;
            this.btnCheck.Text = "Kiểm tra";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button3.Location = new System.Drawing.Point(609, 143);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(141, 57);
            this.button3.TabIndex = 21;
            this.button3.Text = "Chọn Menu";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btDatTiec
            // 
            this.btDatTiec.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btDatTiec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDatTiec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btDatTiec.Location = new System.Drawing.Point(609, 361);
            this.btDatTiec.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btDatTiec.Name = "btDatTiec";
            this.btDatTiec.Size = new System.Drawing.Size(141, 50);
            this.btDatTiec.TabIndex = 23;
            this.btDatTiec.Text = "Đặt tiệc";
            this.btDatTiec.UseVisualStyleBackColor = false;
            this.btDatTiec.Click += new System.EventHandler(this.btDatTiec_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 27F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(329, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 52);
            this.label9.TabIndex = 24;
            this.label9.Text = "Đặt Tiệc";
            // 
            // cbCa
            // 
            this.cbCa.FormattingEnabled = true;
            this.cbCa.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cbCa.Location = new System.Drawing.Point(398, 228);
            this.cbCa.Name = "cbCa";
            this.cbCa.Size = new System.Drawing.Size(94, 24);
            this.cbCa.TabIndex = 25;
            // 
            // FDatTiec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjectWedding.Properties.Resources.MagnetStreet_PinkMarble_1920x1080;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cbCa);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btDatTiec);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btXuathoadon);
            this.Controls.Add(this.cbSanh);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbSlBan);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbTienCoc);
            this.Controls.Add(this.NgayDT);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbDT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbTenCD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbTenCR);
            this.Controls.Add(this.btdtReturn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FDatTiec";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FDatTiec";
            this.Load += new System.EventHandler(this.FDatTiec_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btdtReturn;
        private System.Windows.Forms.TextBox tbTenCR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTenCD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbDT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker NgayDT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbTienCoc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbSlBan;
        private System.Windows.Forms.ComboBox cbSanh;
        private System.Windows.Forms.Button btXuathoadon;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btDatTiec;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbCa;
    }
}